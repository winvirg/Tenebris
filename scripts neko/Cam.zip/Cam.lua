frame = 0
offx = 0
spdx = 0
firstx = 0
offy = 0
spdy = 0
firsty= 0
edgex = 0
edgey = 0
gh = 0




Client.RunLater(function()



ClientUnit = Camera.target
forX = ClientUnit.x
forY = ClientUnit.y

Client.onTick.Add(function()

if frame == 2 then

	frame = 0

if edgex == 0 then------------

	if forX != ClientUnit.x then -- �̵���

		if forX > ClientUnit.x then

			if firstx == 0 then -- ù ������
				firstx = 1
				spdx = 2
			else -- ������
				spdx = spdx - 0.1
			end

			if spdx < 0 then
				spdx = 0
			end

		else

			if firstx == 0 then -- ù ������
				firstx = 1
				spdx = -2
			else -- ������
				spdx = spdx + 0.1
			end

			if spdx > 0 then
				spdx = 0
			end

		end

	else -- ������

		if offx > 0 then

			if firstx == 1 then -- �̵��� ����
				spdx = -2
				firstx = 0
			else -- ������
				spdx = spdx + 0.1
			end

			if spdx > 0 then
				spdx = 0
			end

		else

			if firstx == 1 then -- �̵��� ����
				spdx = 2
				firstx = 0
			else -- ������
				spdx = spdx - 0.1
			end

			if spdx < 0 then
				spdx = 0
			end

		end

	end

end--------


if edgey == 0 then

	if forY != ClientUnit.y then -- �̵���

		if forY > ClientUnit.y then

			if firsty == 0 then -- ù ������
				firsty = 1
				spdy = 2
			else -- ������
				spdy = spdy - 0.1
			end

			if spdy < 0 then
				spdy = 0
			end

		else

			if firsty == 0 then -- ù ������
				firsty = 1
				spdy = -2
			else -- ������
				spdy = spdy + 0.1
			end

			if spdy > 0 then
				spdy = 0
			end

		end

	else -- ������

		if offy > 0 then

			if firsty == 1 then -- �̵��� ����
				spdy = -2
				firsty = 0
			else -- ������
				spdy = spdy + 0.1
			end

			if spdy > 0 then
				spdy = 0
			end

		else

			if firsty == 1 then -- �̵��� ����
				spdy = 2
				firsty = 0
			else -- ������
				spdy = spdy - 0.1
			end

			if spdy < 0 then
				spdy = 0
			end

		end

	end

end-------------

	offy = offy + spdy
	if offy < -18 then
		offy = -18
	end
	if offy > 18 then
		offy = 18
	end
	forY = ClientUnit.y -- ������ǥ


	offx = offx + spdx
	if offx < -18 then
		offx = -18
	end
	if offx > 18 then
		offx = 18
	end
	forX = ClientUnit.x -- ������ǥ


end --frame

local z = Client.field.width*32 - Client.width / 2 + 80
if ClientUnit.x < Client.width / 2-80 - offx then

	ssx = Client.width / 2-80 - offx
	edgex = 1
	offx = 0
	firstx = 0

elseif ClientUnit.x > z then

	ssx = z
	edgex = 1
	offx = 0
	firstx = 0

else

	if edgex == 1 then
		edgex = 0
		offx = offx * -1
	end
	ssx = ClientUnit.x + offx

end



local w = Client.field.width*32 - Client.height/2 + 60
if -ClientUnit.y < Client.height / 2-40 + offy then

	ssy = Client.height / 2-40 + offy
	edgey = 1
	offy = 0
	firsty = 0

elseif -ClientUnit.y > w then

	ssy = w
	edgey = 1
	offy = 0
	firsty = 0

else

	if edgey == 1 then
		edgey = 0
		offy = offy * -1
	end

	ssy = -ClientUnit.y - offy

end


if Client.field.height > 15 and Client.field.width > 25 then
	Camera.position = Point( ssx , ssy ) --ī�޶�+������
else
	Camera.target = ClientUnit
end

frame = frame + 1

end)

end,1)