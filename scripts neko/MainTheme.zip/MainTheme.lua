GameStart = Button("게임 시작", Rect(Client.width / 2.2, Client.height / 2.1, 100, 50))
GameNotice = Button("공지 사항", Rect(Client.width / 2.2, Client.height / 1.7, 100, 50))
GameExit = Button("게임 종료", Rect(Client.width / 2.2, Client.height / 1.432, 100, 50))
MainT = Image("Pictures/DarkOnline.jpg", Rect(0, 0, Client.width, Client.height)) -- Pictures/DarkOnline.jpg를 자신이 넣은 사진의 경로로 수정해주세요.

GameStart.onClick.Add(function()
	GameStart.Destroy()
	GameNotice.Destroy()
	GameExit.Destroy()
	MainT.Destroy()
end)

GameNotice.onClick.Add(function()
	Client.ShowAlert("다크 온라인의 오픈 베타가 곧 시작됩니다.") -- 공지사항 텍스트를 수정해주세요.
end)

GameExit.onClick.Add(function()
	function GameShotDown()
		GameStart.Destroy()
		GameNotice.Destroy()
		GameExit.Destroy()
		MainT.Destroy()
		Client.Quit()
	end
	Client.ShowYesNoAlert("정말 종료 하시겠습니까?", GameShotDown)
end)

MainT.showOnTop = true
GameStart.showOnTop = true
GameNotice.showOnTop = true
GameExit.showOnTop = true