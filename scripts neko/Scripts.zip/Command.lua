
function split(s, delimiter)
    result = {};
    for match in (s..delimiter):gmatch("(.-)"..delimiter) do
        table.insert(result, match);
    end
    return result;
end

local admin = "TEST_1"

function onSay(unit, text)
	if (unit.player.name == admin) then
		if (string.match(text, "/view warehouse")) then
			text = text:gsub("/view warehouse", "")
			text = split(text, " ")
			for i, rp in ipairs(Server.players) do
				if rp.unit.player.name == text[1] then
					local list = {name, id, item, size}
					list.name = text[1]
					list.id = tonumber(text[2])
					list.size = #rp.unit.player.GetStorageItems(list.id)
					list.item = {}
					for i=1, #rp.unit.player.GetStorageItems(list.id) do
						list.item[i] = {dataID, count}
						list.item[i].dataID = rp.unit.player.GetStorageItems(list.id)[i].dataID
						list.item[i].count = rp.unit.player.GetStorageItems(list.id)[i].count
					end
					list = Utility.JSONSerialize(list)
					unit.FireEvent("viewStorage", list)
				end
			end
		end
	end
end
Server.onSay.Add(onSay)
