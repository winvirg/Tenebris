
local itemImage = {}

---------------------------------------
itemImage[8] = "fire_sword"
itemImage[9] = "item_0111"
-- itemImage[dataID] = "image"
---------------------------------------

Client.getTopic("viewStorage").Add(function(text)
	local list = Utility.JSONParse(text)

	local panel = Panel()
	panel.rect = Rect(Client.width/2-185, Client.height/2-177, 370, 354)
	panel.color = Color(41, 41, 41)
	panel.SetOpacity(245)
	panel.showOnTop = true

	local titleText = Text()
	titleText.textSize = 17
	titleText.textAlign = 1
	titleText.rect = Rect(185-34, 12, 90, 30)
	titleText.text = list.id.."번 창고"

	local itemScroll = ScrollPanel()
	itemScroll.rect = Rect(20, 40, 336, 270)
	itemScroll.SetOpacity(0)

	local itemPanel = Panel()
	itemPanel.rect = Rect(0, 0, 336, 42*math.ceil(list.size/6)+(math.ceil(list.size/6)*9))
	itemPanel.SetOpacity(0)

	local listItem = {}
	local listItemButton = {}
	for i=1, math.ceil(list.size/6) do
		for i2=1, 6 do
			if ((i-1)*6)+i2 <= list.size then
				listItem[((i-1)*6)+i2] = Panel()
				listItem[((i-1)*6)+i2].rect = Rect(((i2-1)*42)+((i2-1)*9), ((i-1)*42)+((i-1)*9)+4, 42, 42)
				listItem[((i-1)*6)+i2].color = Color(64, 64, 64)
				listItem[((i-1)*6)+i2].SetOpacity(200)
				if list.item[((i-1)*6)+i2].dataID > 0 then
					listItem[((i-1)*6)+i2].AddChild(Image("Icons/"..itemImage[list.item[((i-1)*6)+i2].dataID]..".png", Rect(0, 0, 42, 42)))
				end
				itemPanel.AddChild(listItem[((i-1)*6)+i2])
			end
		end
	end

	local closeButton = Button()
	closeButton.rect = Rect(370/2-50, 354-30-8, 100, 30)
	closeButton.color = Color(81, 81, 81)
	closeButton.SetOpacity(255)
	closeButton.text = "확인"
	closeButton.onClick.Add(function()
		panel.Destroy()
	end)
	panel.AddChild(closeButton)
	panel.AddChild(titleText)
	panel.AddChild(yaddo)
	panel.AddChild(itemScroll)

	itemScroll.AddChild(itemPanel)
	itemScroll.content = itemPanel
	itemScroll.horizontal = false
	itemScroll.showVerticalScrollbar = true
end)