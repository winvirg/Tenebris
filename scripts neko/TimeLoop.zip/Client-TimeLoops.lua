--[[
------------------------------------------------
※무단 복제, 수정 환영합니다!!!!   (가급적 수정후 공유해주시길)


※문제가 있다면 카카오톡 

  https://open.kakao.com/me/Std_h0
------------------------------------------------


사용법!!!!

------------------------------------------------

  For( 시작값 , 끝값 , 증가값 , 실행내용 , 끝나면실행 )

------------------------------------------------
※알아둬야할 사항!!!!!!

  [ 시작값 < 끝값 ]  (필수)	이렇게 안하면 이상하게 실행된다!

  [ "끝나면실행" ]		여긴 생략해도 좋다!
			파라미터로 끝값이 들어간다!

  [ 동시사용 ]		동시에 사용해도 멀쩡히 작동!

------------------------------------------------


------------------------------------------------

  While( 조건함수 , 실행함수 , 끝나면실행 )

------------------------------------------------
※알아둬야할 사항!!!!!!

  [ 조건함수 ]     (필수)	참,거짓을 반환하는 함수여야 한다!
			입력되는 파라미터는 없다!

  [ "끝나면실행" ]		여긴 생략해도 좋다!
			입력되는 파라미터는 없다!

  [ 동시사용 ]		동시에 사용해도 멀쩡히 작동!

-------------------------------------------------

]]

fors = {}

whiles = {}

Client.onTick.Add(function()
	
	if fors != {} then
		for a = #fors,1,-1 do
			if fors[a][1] <= fors[a][2] then
				fors[a][4](fors[a][1])
				fors[a][1] = fors[a][1]+fors[a][3]
			else
				fors[a][5](fors[a][1])
				table.remove(fors,a)
			end
		end
	end
	if whiles != {} then
		for a = #whiles,1,-1 do
			if whiles[a][1]() == true then
				whiles[a][2]()
			else
				whiles[a][3](whiles[a][1]())
				table.remove(whiles,a)
			end
		end
	end
	
end)

function For(a,b,c,func,Wend)
	Wend = Wend or function() end
	fors[#fors+1] = {a,b,c,func,Wend}
end

function While(logic,func,Wend)
	Wend = Wend or function() end
	whiles[#whiles+1] = {logic,func,Wend}
end