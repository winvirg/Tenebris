------------------------------------------------------------

local TitleVar = 100 -- 칭호 변수 변호입니다.
local TitleColor = 101
local NameVar = 102 -- 닉네임 색상 변수 변호입니다.

local LvColor = "<color=#FF5E00>"

local LvView = true -- 레벨 표기 설정입니다.

------------------------------------------------------------

function TitleSet(text, color)
	unit.SetStringVar(TitleVar, text)
	unit.SetStringVar(TitleColor, "<color=#"..color..">")
	if (LvView == true) then
		unit.name = unit.GetStringVar(TitleColor)..unit.GetStringVar(TitleVar).."</color>\n"..LvColor.."Lv."..unit.level.." </color>"..unit.GetStringVar(NameVar)..unit.player.name.."</color>"
	else
		unit.name = unit.GetStringVar(TitleColor)..unit.GetStringVar(TitleVar).."</color>\n"..unit.GetStringVar(NameVar)..unit.player.name.."</color>"
	end
	unit.SendUpdated()
end

function TitleDel()
	unit.SetStringVar(TitleVar, "Nil")
	if (LvView == true) then
		unit.name = LvColor.."Lv."..unit.level.." </color>"..unit.GetStringVar(NameVar)..unit.player.name.."</color>"
	else
		unit.name = unit.player.name
	end
	unit.SendUpdated()
end

function NameSet(text)
	unit.SetStringVar(NameVar, "<color=#"..text..">")
	TitleRefresh()
end

function TitleRefresh()
	if (unit.GetVar(NameVar) == 0) then
		unit.SetVar(NameVar, 1)
		unit.SetVar(TitleColor, 1)
		unit.SetStringVar(NameVar, "<color=#FFFFFF>")
		unit.SetStringVar(TitleColor, "<color=#FF5000>")
	end
	if (unit.GetStringVar(TitleVar) == "Nil") then
		if (LvView == true) then
			unit.name = LvColor.."Lv."..unit.level.." </color>"..unit.GetStringVar(NameVar)..unit.player.name.."</color>"
		else
			unit.name = unit.player.name
		end
	else
		if (LvView == true) then
			unit.name = unit.GetStringVar(TitleColor)..unit.GetStringVar(TitleVar).."</color>\n"..LvColor.."Lv."..unit.level.." </color>"..unit.GetStringVar(NameVar)..unit.player.name.."</color>"
		else
			unit.name = unit.GetStringVar(TitleColor)..unit.GetStringVar(TitleVar).."</color>\n"..unit.GetStringVar(NameVar)..unit.player.name.."</color>"
		end
		unit.SendUpdated()
	end
end

function onUnitLevelUp(target, level)
	if (target.GetStringVar(TitleVar) == "Nil") then
		if (LvView == true) then
			target.name = LvColor.."Lv."..target.level.." </color>"..target.GetStringVar(NameVar)..target.player.name.."</color>"
		else
			target.name = target.player.name
		end
	else
		if (LvView == true) then
			target.name = target.GetStringVar(TitleColor)..target.GetStringVar(TitleVar).."</color>\n"..LvColor.."Lv."..target.level.." </color>"..target.GetStringVar(NameVar)..target.player.name.."</color>"
		else
			target.name = target.GetStringVar(TitleColor)..target.GetStringVar(TitleVar).."</color>\n"..target.GetStringVar(NameVar)..target.player.name.."</color>"
		end
		target.SendUpdated()
	end
end

Server.onUnitLevelUp.Add(onUnitLevelUp)