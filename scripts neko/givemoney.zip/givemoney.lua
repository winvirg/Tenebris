
function givemoney(money)
unit.AddGameMoney(money)
Server.SendCenterLabel(money.."원을 지급받았습니다.")
end