﻿function onUnitLevelUp(target, level)

	target.StartGlobalEvent() -- 괄호 안에 SE SE 재생 공용 이벤트 번호를 넣어주세요.
	
end
 
Server.onUnitLevelUp.Add(onUnitLevelUp)