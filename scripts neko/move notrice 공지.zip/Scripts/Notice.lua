Client.GetTopic("notice").Add(function(text)
	local noticepanel = Panel()	 -- 패널생성은 필요요소가 없습니다.
	noticepanel.SetOpacity(150)
	noticepanel.rect = Rect(0, 80, Client.width, 40)
	noticetxt = Text("",Rect(Client.width-(Client.width/2), 90, Client.width, 40))
	noticetxt.text = text
	noticetxt.textAlign = 2
	noticetxt.DOMove(Point(-Client.width-(Client.width),90), 35)
	Client.RunLater(function()   -- 2.5초 있다가 실행
		noticepanel.Destroy()  -- 패널 제거(AddChild로 들어간 텍스트도 같이 삭제)
		noticetxt.Destroy()
	end,15)
end)

-- https://cafe.naver.com/nekolandgames/2264 참고했습니다.