function onSay(unit, text)
	if (unit.player.name == "TEST_1") then
		for i, rp in ipairs(Server.players) do
			if (string.match(text, "/공지 ")) then
				text = text:gsub("/공지 ", "")
				Server.FireEvent("notice", text)
				return false
			end
		end
	end
end

Server.onSay.Add(onSay)