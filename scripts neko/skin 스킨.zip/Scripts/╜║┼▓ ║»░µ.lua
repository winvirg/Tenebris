
local skin = {name = {}, explain = {}, image = {}}
skin.name[1] = "스킨1"
skin.explain[1] = "이동속도 +15%"
skin.image[1] = "Icons/Icon_Unit_02.png"

skin.name[2] = "스킨2"
skin.explain[2] = "이동속도 +25%\n체력 +15%"
skin.image[2] = "Icons/Icon_Unit_03.png"

skin.name[3] = "스킨3"
skin.explain[3] = "이동속도 +25%\n마나 +15%"
skin.image[3] = "Icons/Icon_Unit_08.png"

skin.name[4] = "스킨4"
skin.explain[4] = "이동속도 +30%\n체력 +15%"
skin.image[4] = "Icons/Icon_Unit_38.png"

skin.name[5] = "스킨5"
skin.explain[5] = "이동속도 +15%"
skin.image[5] = "Icons/Icon_Unit_22.png"

skin.name[6] = "스킨6"
skin.explain[6] = "이동속도 +15%"
skin.image[6] = "Icons/Icon_Unit_06.png"

skin.name[7] = "스킨7"
skin.explain[7] = "이동속도 +30%\n체력 +15%"
skin.image[7] = "Icons/Icon_Unit_05.png"

skin.name[8] = "스킨8"
skin.explain[8] = "이동속도 +30%\n체력 +15%"
skin.image[8] = "Icons/Icon_Unit_20.png"

skin.name[9] = "스킨9"
skin.explain[9] = "이동속도 +10%"
skin.image[9] = "Icons/Icon_Unit_39.png"

skin.name[10] = "스킨10"
skin.explain[10] = "이동속도 +40%\n체력 +18%\n마나 +18%\n공격력 +4%"
skin.image[10] = "Icons/Icon_Unit_36.png"

skin.name[11] = "스킨11"
skin.explain[11] = "이동속도 +20%"
skin.image[11] = "Icons/Icon_Unit_37.png"

function openSkin()
	local mask = Panel(Rect(0, 0, Client.width, Client.height))
	mask.color = Color(0, 0, 0)
	mask.SetOpacity(145)
	mask.showOnTop = true

	local panel = Image("Pictures/skin_scroll_panel.png", Rect(Client.width/2-183, Client.height/2-225, 366, 450))

	local scroll = ScrollPanel(Rect(11, 51, 344, 386))
	scroll.SetOpacity(0)

	local board = Panel(Rect(0, 0, 344, (#skin.name*95)+((#skin.name-1)*6)))

	local list = {panel = {}, buttonImage = {}, button = {}, nameText = {}, explain = {}, image = {}}
	for i=1, #skin.name do
		list.panel[i] = Image("Pictures/warp_panel.png", Rect(0, ((i-1)*95)+((i-1)*6), 344, 95))
		board.AddChild(list.panel[i])

		list.nameText[i] = Text(skin.name[i], Rect(92, 11, 167, 18))
		list.nameText[i].color = Color(0, 0, 0)
		list.explain[i] = Text(skin.explain[i], Rect(91, 34, 150, 47))
		list.explain[i].textSize = 12
		list.explain[i].color = Color(0, 0, 0)
		list.image[i] = Image(skin.image[i], Rect(12, 13, 69, 69))
		list.buttonImage[i] = Image("Pictures/skinChangeButton.png", Rect(242, 44, 94, 43))
		list.button[i] = Button("", Rect(242, 44, 94, 43))
		list.button[i].SetOpacity(0)
		list.button[i].onClick.Add(function()
			list.buttonImage[i].SetImage("Pictures/skinChangeButton_press.png")
			Client.RunLater(function()
				list.buttonImage[i].SetImage("Pictures/skinChangeButton.png")
				Client.FireEvent("Y_skinChange", i)
				mask.Destroy()
			end,0.1)
		end)
		list.panel[i].AddChild(list.nameText[i])
		list.panel[i].AddChild(list.explain[i])
		list.panel[i].AddChild(list.image[i])
		list.panel[i].AddChild(list.buttonImage[i])
		list.panel[i].AddChild(list.button[i])
	end

	scroll.content = board
	scroll.horizontal = false
	scroll.AddChild(board)

	local closeButton = Button("", Rect(366-23-6, 6, 23, 23))
	closeButton.AddChild(Image("Pictures/CloseButton.png", Rect(0, 0, 23, 23)))
	closeButton.SetOpacity(0)
	closeButton.onClick.Add(function()
		mask.Destroy()
	end)

	panel.AddChild(closeButton)
	panel.AddChild(scroll)
	mask.AddChild(panel)
end
