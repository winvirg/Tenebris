
local var = 28

local skin = {characterID = {}}
skin.characterID[1] = 1
skin.characterID[2] = 2
skin.characterID[3] = 3
skin.characterID[4] = 4
skin.characterID[5] = 5
skin.characterID[6] = 6
skin.characterID[7] = 7
skin.characterID[8] = 8
skin.characterID[9] = 9
skin.characterID[10] = 15
skin.characterID[11] = 16

Server.GetTopic("Y_skinChange").Add(function(text)
	local data = Utility.JSONParse(unit.GetStringVar(var))
	if data.skinID[tostring(text)] == "true" then
		unit.characterID = skin.characterID[text]
		unit.SendUpdated()
	else
		unit.SendCenterLabel("스킨을 보유하고 있지 않습니다.")
	end
end)

function setSkin(text)
	local a = Utility.JSONParse(unit.GetStringVar(var))
	a.skinID[tostring(text)] = "true"
	unit.SetStringVar(var, Utility.JSONSerialize(a))
end