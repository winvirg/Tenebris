Server.GetTopic("WB").Add(function(text)
unit.StartGlobalEvent(2)
end)